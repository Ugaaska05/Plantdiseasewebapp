/*
  # Create Admin User in Authentication System

  1. Admin User Setup
    - Creates admin user in auth.users table
    - Email: admin@hiigsigroup.com
    - Password: admin123 (hashed)
    - Email confirmed automatically
    - Role set to admin in users table

  2. Security
    - Password is properly hashed using Supabase's auth system
    - Email confirmation bypassed for admin account
    - Admin role assigned in custom users table
*/

-- Insert admin user into auth.users table
INSERT INTO auth.users (
  instance_id,
  id,
  aud,
  role,
  email,
  encrypted_password,
  email_confirmed_at,
  recovery_sent_at,
  last_sign_in_at,
  raw_app_meta_data,
  raw_user_meta_data,
  created_at,
  updated_at,
  confirmation_token,
  email_change,
  email_change_token_new,
  recovery_token
) VALUES (
  '00000000-0000-0000-0000-000000000000',
  gen_random_uuid(),
  'authenticated',
  'authenticated',
  'admin@hiigsigroup.com',
  crypt('admin123', gen_salt('bf')),
  NOW(),
  NOW(),
  NOW(),
  '{"provider": "email", "providers": ["email"]}',
  '{"name": "Admin User"}',
  NOW(),
  NOW(),
  '',
  '',
  '',
  ''
) ON CONFLICT (email) DO NOTHING;

-- Insert admin user into our custom users table
INSERT INTO users (
  id,
  email,
  name,
  password_hash,
  role,
  disabled,
  created_at,
  updated_at
) 
SELECT 
  au.id,
  'admin@hiigsigroup.com',
  'Admin User',
  au.encrypted_password,
  'admin',
  false,
  NOW(),
  NOW()
FROM auth.users au 
WHERE au.email = 'admin@hiigsigroup.com'
ON CONFLICT (email) DO UPDATE SET
  role = 'admin',
  disabled = false,
  updated_at = NOW();