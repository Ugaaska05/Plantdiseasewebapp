@@ .. @@
 CREATE TABLE IF NOT EXISTS users (
   id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
   email text UNIQUE NOT NULL,
   name text NOT NULL,
   password_hash text NOT NULL,
   role text DEFAULT 'user',
+  status text DEFAULT 'pending',
+  email_verified boolean DEFAULT false,
   created_at timestamptz DEFAULT now(),
   updated_at timestamptz DEFAULT now()
 );

--- Add status column
-ALTER TABLE users ADD COLUMN IF NOT EXISTS status text DEFAULT 'pending';
-ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified boolean DEFAULT false;
-
 -- Add constraint for role
 ALTER TABLE users ADD CONSTRAINT users_role_check 
   CHECK (role IN ('user', 'admin'));

 -- Add constraint for status  
 ALTER TABLE users ADD CONSTRAINT users_status_check 
   CHECK (status IN ('pending', 'approved', 'rejected', 'suspended'));