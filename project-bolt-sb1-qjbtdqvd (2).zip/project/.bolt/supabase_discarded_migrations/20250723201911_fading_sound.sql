@@ .. @@
   id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
   email text UNIQUE NOT NULL,
   name text NOT NULL,
   password_hash text NOT NULL,
   role text DEFAULT 'user'::text,
+  status text DEFAULT 'pending'::text,
   email_verified boolean DEFAULT false,
   created_at timestamptz DEFAULT now(),
   updated_at timestamptz DEFAULT now()
 );

@@ .. @@
 ALTER TABLE users ENABLE ROW LEVEL SECURITY;

+-- Add constraint for status values
+ALTER TABLE users ADD CONSTRAINT users_status_check 
+CHECK (status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text, 'suspended'::text]));
+
 -- Add constraint for role values
 ALTER TABLE users ADD CONSTRAINT users_role_check 
 CHECK (role = ANY (ARRAY['user'::text, 'admin'::text]));

@@ .. @@
 -- Insert default admin user
 INSERT INTO users (name, email, password_hash, role, status, email_verified)
 VALUES (
   'Admin User',
   'admin@plantdisease.com',
   '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXig/pxmN4F2', -- password: admin123
-  'admin',
+  'admin',
+  'approved',
   true
 ) ON CONFLICT (email) DO NOTHING;