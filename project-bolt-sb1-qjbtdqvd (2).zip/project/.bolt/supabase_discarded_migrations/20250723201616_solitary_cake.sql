/*
  # Complete Plant Disease Classifier Database Schema

  1. New Tables
    - `users` - User accounts with admin approval system
      - `id` (uuid, primary key)
      - `email` (text, unique)
      - `name` (text)
      - `password_hash` (text)
      - `role` (text, default 'user')
      - `status` (text, default 'pending')
      - `email_verified` (boolean, default false)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

    - `user_verifications` - OTP email verification system
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key)
      - `otp_code` (text)
      - `verification_type` (text)
      - `expires_at` (timestamp)
      - `created_at` (timestamp)

    - `admin_approvals` - Admin approval tracking
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key)
      - `admin_id` (uuid, foreign key)
      - `action` (text)
      - `reason` (text)
      - `created_at` (timestamp)

    - `predictions` - AI disease detection results
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key)
      - `image_name` (text)
      - `prediction_stage` (text)
      - `prediction_label` (text)
      - `friendly_text` (text)
      - `suggestion` (text)
      - `confidence` (decimal)
      - `language` (text, default 'en')
      - `created_at` (timestamp)

    - `user_sessions` - Authentication session management
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key)
      - `token` (text)
      - `expires_at` (timestamp)
      - `created_at` (timestamp)

    - `system_settings` - Application configuration
      - `id` (uuid, primary key)
      - `setting_key` (text, unique)
      - `setting_value` (text)
      - `description` (text)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    - Add admin-only policies for management tables

  3. Functions
    - `verify_otp()` - OTP verification function
    - `admin_approve_user()` - User approval function

  4. Default Data
    - Create default admin account
    - Insert default system settings
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  name text NOT NULL,
  password_hash text NOT NULL,
  role text DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'suspended')),
  email_verified boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create user_verifications table
CREATE TABLE IF NOT EXISTS user_verifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  otp_code text NOT NULL,
  verification_type text NOT NULL DEFAULT 'email',
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create admin_approvals table
CREATE TABLE IF NOT EXISTS admin_approvals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  admin_id uuid REFERENCES users(id) ON DELETE SET NULL,
  action text NOT NULL CHECK (action IN ('approve', 'reject', 'suspend')),
  reason text,
  created_at timestamptz DEFAULT now()
);

-- Create predictions table
CREATE TABLE IF NOT EXISTS predictions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  image_name text NOT NULL,
  prediction_stage text,
  prediction_label text NOT NULL,
  friendly_text text NOT NULL,
  suggestion text NOT NULL,
  confidence decimal(5,2) NOT NULL,
  language text DEFAULT 'en',
  created_at timestamptz DEFAULT now()
);

-- Create user_sessions table
CREATE TABLE IF NOT EXISTS user_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  token text UNIQUE NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create system_settings table
CREATE TABLE IF NOT EXISTS system_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  setting_key text UNIQUE NOT NULL,
  setting_value text,
  description text,
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security on all tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_verifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_approvals ENABLE ROW LEVEL SECURITY;
ALTER TABLE predictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;

-- Users table policies
CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Admins can read all users"
  ON users
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Admins can update user status"
  ON users
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- User verifications policies
CREATE POLICY "Users can read own verifications"
  ON user_verifications
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Anyone can insert verifications"
  ON user_verifications
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Admin approvals policies
CREATE POLICY "Admins can read all approvals"
  ON admin_approvals
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Admins can insert approvals"
  ON admin_approvals
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Predictions table policies
CREATE POLICY "Users can read own predictions"
  ON predictions
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own predictions"
  ON predictions
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can read all predictions"
  ON predictions
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- User sessions policies
CREATE POLICY "Users can read own sessions"
  ON user_sessions
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own sessions"
  ON user_sessions
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can delete own sessions"
  ON user_sessions
  FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

-- System settings policies
CREATE POLICY "Admins can read system settings"
  ON system_settings
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

CREATE POLICY "Admins can update system settings"
  ON system_settings
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users 
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Create OTP verification function
CREATE OR REPLACE FUNCTION verify_otp(
  p_user_id uuid,
  p_otp_code text,
  p_verification_type text DEFAULT 'email'
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_valid boolean := false;
BEGIN
  -- Check if OTP is valid and not expired
  SELECT EXISTS(
    SELECT 1 FROM user_verifications
    WHERE user_id = p_user_id
      AND otp_code = p_otp_code
      AND verification_type = p_verification_type
      AND expires_at > now()
  ) INTO v_valid;
  
  IF v_valid THEN
    -- Mark email as verified
    UPDATE users 
    SET email_verified = true, updated_at = now()
    WHERE id = p_user_id;
    
    -- Delete used OTP
    DELETE FROM user_verifications
    WHERE user_id = p_user_id
      AND otp_code = p_otp_code
      AND verification_type = p_verification_type;
      
    RETURN true;
  END IF;
  
  RETURN false;
END;
$$;

-- Create admin approval function
CREATE OR REPLACE FUNCTION admin_approve_user(
  p_user_id uuid,
  p_admin_id uuid,
  p_action text,
  p_reason text DEFAULT NULL
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_admin_valid boolean := false;
BEGIN
  -- Check if admin is valid
  SELECT EXISTS(
    SELECT 1 FROM users
    WHERE id = p_admin_id AND role = 'admin'
  ) INTO v_admin_valid;
  
  IF NOT v_admin_valid THEN
    RETURN false;
  END IF;
  
  -- Update user status
  UPDATE users 
  SET status = p_action, updated_at = now()
  WHERE id = p_user_id;
  
  -- Record admin action
  INSERT INTO admin_approvals (user_id, admin_id, action, reason)
  VALUES (p_user_id, p_admin_id, p_action, p_reason);
  
  RETURN true;
END;
$$;

-- Insert default admin user (change password in production!)
INSERT INTO users (name, email, password_hash, role, status, email_verified)
VALUES (
  'System Admin',
  'admin@plantdisease.com',
  '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/VcSAg/9qm', -- password: admin123
  'admin',
  'approved',
  true
) ON CONFLICT (email) DO NOTHING;

-- Insert default system settings
INSERT INTO system_settings (setting_key, setting_value, description) VALUES
  ('max_file_size', '10485760', 'Maximum file size in bytes (10MB)'),
  ('supported_formats', 'jpg,jpeg,png', 'Supported image formats'),
  ('confidence_threshold', '80', 'Minimum confidence threshold for predictions'),
  ('model_version', '1.0', 'Current AI model version'),
  ('otp_expiry_minutes', '10', 'OTP expiry time in minutes'),
  ('session_expiry_days', '7', 'User session expiry in days')
ON CONFLICT (setting_key) DO NOTHING;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);
CREATE INDEX IF NOT EXISTS idx_user_verifications_user_id ON user_verifications(user_id);
CREATE INDEX IF NOT EXISTS idx_user_verifications_otp ON user_verifications(otp_code);
CREATE INDEX IF NOT EXISTS idx_admin_approvals_user_id ON admin_approvals(user_id);
CREATE INDEX IF NOT EXISTS idx_predictions_user_id ON predictions(user_id);
CREATE INDEX IF NOT EXISTS idx_predictions_created_at ON predictions(created_at);
CREATE INDEX IF NOT EXISTS idx_user_sessions_user_id ON user_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_user_sessions_token ON user_sessions(token);
CREATE INDEX IF NOT EXISTS idx_system_settings_key ON system_settings(setting_key);