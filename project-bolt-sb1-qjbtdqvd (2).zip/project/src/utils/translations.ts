export const translations = {
  en: {
    // Navigation
    title: 'Hiigsigroup Plant Disease Classifier',
    subtitle: 'AI-powered system for diagnosing plant diseases — developed by Group 162',
    home: 'Home',
    about: 'About',
    diagnostic: 'Diagnostic',
    contact: 'Contact',
    language: 'English',
    signIn: 'Sign In',
    logout: 'Logout',
    
    // Welcome Page
    welcomeTitle: 'Welcome',
    welcomeSubtitle: 'AI-powered system for diagnosing plant diseases — developed by Group 162 — offering fast, reliable detection and helpful treatment advice for farmers and agricultural communities.',
    getStarted: 'Get Started',
    startDiagnosis: 'Start Diagnosis',
    
    // Home Page (Logged in)
    welcomeBack: 'Welcome',
    homeSubtitle: 'You\'re now inside the revolutionary AI-powered plant health diagnosis system. Start analyzing your plants with instant, accurate disease detection and expert treatment recommendations.',
    
    // Features
    aiPowered: 'AI-Powered Analysis',
    aiDescription: 'Advanced deep learning algorithms trained on thousands of plant images provide highly accurate disease detection with confidence scores.',
    instantResults: 'Instant Results',
    instantDescription: 'Get immediate diagnosis and treatment recommendations within seconds. No waiting, no delays - just instant expert-level analysis.',
    expertRecommendations: 'Expert Recommendations',
    expertDescription: 'Receive professional-grade treatment suggestions and preventive measures based on the specific disease identified in your plants.',
    
    // How it works
    howItWorks: 'How It Works',
    step1Title: 'Upload Image',
    step1Description: 'Take a clear photo of the affected plant leaf and upload it to our secure system.',
    step2Title: 'AI Analysis',
    step2Description: 'Our advanced AI model analyzes the image using deep learning algorithms.',
    step3Title: 'Get Results',
    step3Description: 'Receive detailed diagnosis with confidence scores and treatment recommendations.',
    
    // Stats
    yourDiagnoses: 'Your Diagnoses',
    accuracyRate: 'Accuracy Rate',
    community: 'Community',
    
    // Call to Action
    readyToAnalyze: 'Ready to Analyze Your Plants?',
    readyDescription: 'Start your first plant health diagnosis now and join thousands of satisfied users',
    
    // About Page
    aboutUs: 'About Us',
    aboutDescription: 'Empowering farmers and gardeners with AI-powered plant disease detection technology',
    ourMission: 'Our Mission',
    missionDescription: 'We are dedicated to revolutionizing agriculture through cutting-edge AI technology. Our mission is to provide accessible, accurate, and instant plant disease diagnosis to help farmers and gardeners protect their crops and maximize yields.',
    ourVision: 'Our Vision',
    visionDescription: 'To create a world where every farmer and gardener has access to expert-level plant health diagnosis, reducing crop losses and promoting sustainable agriculture practices through innovative AI solutions.',
    ourTechnology: 'Our Technology',
    advancedML: 'Advanced Machine Learning',
    mlDescription: 'Our system uses state-of-the-art convolutional neural networks trained on thousands of plant images to accurately identify various diseases and health conditions.',
    supportedDiseases: 'Supported Diseases',
    diseasesDescription: 'Currently specialized in tomato plant diseases, with plans to expand to other crops:',
    ourTeam: 'Our Team',
    teamDescription: 'We are a passionate team of agricultural experts, data scientists, and software engineers committed to making plant disease diagnosis accessible to everyone.',
    
    // Upload
    uploadTitle: 'Upload Plant Leaf Image',
    uploadSubtitle: 'Drag and drop an image or click to browse',
    chooseImage: 'Choose Image',
    supportedFormats: 'Supported formats: JPG, PNG (max 10MB)',
    
    // Results
    confidence: 'Confidence',
    recommendation: 'Recommendation',
    tryAnother: 'Try Another Image',
    
    // History
    history: 'History',
    clearHistory: 'Clear History',
    noHistory: 'No previous diagnoses',
    
    // Footer
    quickLinks: 'Quick Links',
    privacyPolicy: 'Privacy Policy',
    termsOfService: 'Terms of Service',
    support: 'Support',
    copyright: '© 2025 Hiigsigroup – Group 162. All rights reserved.',
    contactEmail: 'hiigsi162@gmail.com',
    contactPhone: '+252 615 479005',
    contactAddress: 'Somali Agricultural Innovation Center, Mogadishu',
    
    // Auth
    loginTitle: 'Sign in to your account',
    signupTitle: 'Create Account',
    email: 'Email Address',
    password: 'Password',
    confirmPassword: 'Confirm Password',
    fullName: 'Full Name',
    userLogin: 'User Login',
    adminLogin: 'Admin Login',
    createAccount: 'Create Account',
    backToLogin: 'Back to Login',
    dontHaveAccount: 'Don\'t have an account?',
    alreadyHaveAccount: 'Already have an account?',
    signUpHere: 'Sign up here',
    signInHere: 'Sign in here'
  },
  so: {
    // Navigation
    title: 'Hiigsigroup Kala-soocaha Cudurrada Dhirta',
    subtitle: 'Nidaam AI ah oo ku saabsan ogaanshaha cudurrada dhirta — waxaa sameeyay Kooxda 162',
    home: 'Guriga',
    about: 'Ku Saabsan',
    diagnostic: 'Baaritaan',
    contact: 'Xiriir',
    language: 'Soomaali',
    signIn: 'Gal',
    logout: 'Ka Bax',
    
    // Welcome Page
    welcomeTitle: 'Soo Dhawoow',
    welcomeSubtitle: 'Nidaam AI ah oo ku saabsan ogaanshaha cudurrada dhirta — waxaa sameeyay Kooxda 162 — oo bixiya ogaansho degdeg ah oo la isku halayn karo iyo talo waxtar leh beeraleyda iyo bulshada beeraha.',
    getStarted: 'Bilow',
    startDiagnosis: 'Bilow Baaritaanka',
    
    // Home Page (Logged in)
    welcomeBack: 'Soo Dhawoow',
    homeSubtitle: 'Hadda waxaad ku jirtaa nidaamka casriga ah ee AI-powered ee baaritaanka caafimaadka dhirta. Bilow falanqaynta dhirtaada iyada oo helaysa baaritaan degdeg ah oo sax ah iyo talo takhasuus ah.',
    
    // Features
    aiPowered: 'Falanqayn AI ah',
    aiDescription: 'Algorithms horumarsan oo ku tababaran kumanaan sawir oo dhir ah waxay bixiyaan baaritaan aad u sax ah oo leh heerarka kalsoonida.',
    instantResults: 'Natiijooyin Degdeg ah',
    instantDescription: 'Hel baaritaan degdeg ah iyo talo daaweyn ah dhawr ilbiriqsi gudahood. Ma jiro sugid, ma jiro dib u dhig - kaliya falanqayn takhasuus ah oo degdeg ah.',
    expertRecommendations: 'Talooyinka Takhasuuska',
    expertDescription: 'Hel talooyinka daaweynta ee heerka takhasuuska iyo tallaabooyinka ka-hortagga ee ku salaysan cudurka gaarka ah ee laga helay dhirtaada.',
    
    // How it works
    howItWorks: 'Sida uu u Shaqeeyo',
    step1Title: 'Kor u Qaad Sawirka',
    step1Description: 'Qaad sawir cad oo caleen dhir ah oo saameeysan oo ku soo dir nidaamkeenna ammaan ah.',
    step2Title: 'Falanqaynta AI',
    step2Description: 'Moodeelkeenna AI-ga horumarsan ayaa falanqeeya sawirka isagoo adeegsanaya algorithms barashada qoto dheer.',
    step3Title: 'Hel Natiijooyinka',
    step3Description: 'Hel baaritaan faahfaahsan oo leh dhibcaha kalsoonida iyo talooyinka daaweynta.',
    
    // Stats
    yourDiagnoses: 'Baaritaankaaga',
    accuracyRate: 'Heerka Saxda',
    community: 'Bulshada',
    
    // Call to Action
    readyToAnalyze: 'Diyaar u tahay inaad Falanqayso Dhirtaada?',
    readyDescription: 'Bilow baaritaanka caafimaadka dhirtaada ee ugu horreeya hadda oo ku biir kumanaan isticmaale oo qanacsan',
    
    // About Page
    aboutUs: 'Nagu Saabsan',
    aboutDescription: 'Xoojinta beeraleyda iyo beertoyaasha teknoolajiyada AI-powered ee ogaanshaha cudurrada dhirta',
    ourMission: 'Hadafkeenna',
    missionDescription: 'Waxaan u heellan nahay inaan wax ka beddelno beeraha iyada oo la adeegsanayo teknoolajiyada AI ee casriga ah. Hadafkeenna waa inaan bixinno baaritaan la heli karo, sax ah, degdeg ahna ee cudurrada dhirta si aan u caawino beeraleyda iyo beertoyaasha inay ilaaliyaan dalagoodka oo ay kordhiyaan wax soo saarka.',
    ourVision: 'Aragtideenna',
    visionDescription: 'Inaan abuurno adduun ay ku jiraan dhammaan beeraleyda iyo beertoyaasha ay helaan baaritaan heer takhasuus ah oo caafimaadka dhirta, yaraynta luminta dalagga iyo horumarinta dhaqamada beeraha joogtada ah iyada oo loo marayo xalalka AI ee hal-abuurka leh.',
    ourTechnology: 'Teknoolajiyadeenna',
    advancedML: 'Barashada Makiinada Horumarsan',
    mlDescription: 'Nidaamkeennu wuxuu isticmaalaa shabakadaha neural-ka casriga ah ee ku tababaran kumanaan sawir oo dhir ah si loo aqoonsado si sax ah cudurro kala duwan iyo xaaladaha caafimaadka.',
    supportedDiseases: 'Cudurrada la Taageero',
    diseasesDescription: 'Hadda waxaa lagu takhasusay cudurrada dhirta yaaniska, iyadoo qorshe loo hayo in la ballaariyo dalagga kale:',
    ourTeam: 'Kooxdeenna',
    teamDescription: 'Waxaan nahay koox xamaasad leh oo ka kooban khubarada beeraha, saynisyahanada xogta, iyo injineerada software-ka oo u heellan inay baaritaanka cudurrada dhirta u fududeeyaan qof kasta.',
    
    // Upload
    uploadTitle: 'Kor u Qaad Sawirka Caleenta Dhirta',
    uploadSubtitle: 'Jiid oo dhig sawirka ama riix si aad u raadiso',
    chooseImage: 'Dooro Sawirka',
    supportedFormats: 'Qaababka la taageero: JPG, PNG (ugu badnaan 10MB)',
    
    // Results
    confidence: 'Kalsoonida',
    recommendation: 'Talo',
    tryAnother: 'Isku Day Sawir Kale',
    
    // History
    history: 'Taariikhda',
    clearHistory: 'Nadiifi Taariikhda',
    noHistory: 'Ma jiraan baaritaanno hore',
    
    // Footer
    quickLinks: 'Xidhiidhyo Degdeg ah',
    privacyPolicy: 'Siyaasadda Sirta',
    termsOfService: 'Shuruudaha Adeegga',
    support: 'Taageero',
    copyright: '© 2025 Hiigsigroup – Kooxda 162. Dhammaan xuquuqda way dhowran yihiin.',
    contactEmail: 'hiigsi162@gmail.com',
    contactPhone: '+252 615 479005',
    contactAddress: 'Xarunta Hal-abuurka Beeraha Soomaaliya, Muqdisho',
    
    // Auth
    loginTitle: 'Gal akoonkaaga',
    signupTitle: 'Samee Akoon',
    email: 'Cinwaanka Emailka',
    password: 'Furaha Sirta',
    confirmPassword: 'Xaqiiji Furaha Sirta',
    fullName: 'Magaca Buuxa',
    userLogin: 'Galitaanka Isticmaalaha',
    adminLogin: 'Galitaanka Maamulaha',
    createAccount: 'Samee Akoon',
    backToLogin: 'Ku Noqo Galitaanka',
    dontHaveAccount: 'Ma lihid akoon?',
    alreadyHaveAccount: 'Akoon ma leedahay?',
    signUpHere: 'Halkan ka diwaangeli',
    signInHere: 'Halkan ka gal'
  }
};

export type TranslationKey = keyof typeof translations.en;
export type Language = 'en' | 'so';