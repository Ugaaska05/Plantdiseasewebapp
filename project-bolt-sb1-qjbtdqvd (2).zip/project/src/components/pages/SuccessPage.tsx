import React, { useEffect, useState } from 'react';
import { CheckCircle, ArrowRight, Crown } from 'lucide-react';

interface SuccessPageProps {
  onNavigateHome: () => void;
}

export const SuccessPage: React.FC<SuccessPageProps> = ({ onNavigateHome }) => {

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl p-12 max-w-2xl w-full text-center">
        <div className="mb-8">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="h-12 w-12 text-green-600" />
          </div>
          
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Payment Successful!
          </h1>
          
          <p className="text-xl text-gray-600 mb-8">
            Thank you for your purchase. Your account has been activated.
          </p>
        </div>

        <div className="bg-green-50 rounded-2xl p-6 mb-8 border border-green-200">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Crown className="h-6 w-6 text-green-600" />
            <h3 className="text-xl font-bold text-gray-900">Access Granted</h3>
          </div>
          
          <div className="space-y-2">
            <p className="text-lg font-semibold text-gray-900">Plant Disease Detection</p>
            <p className="text-gray-600">You now have full access to all features</p>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-xl font-bold text-gray-900 mb-4">What's Next?</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 mb-2">Start Diagnosing</h4>
              <p className="text-sm text-gray-600">
                Upload plant images and get instant disease detection with treatment recommendations.
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 mb-2">Track History</h4>
              <p className="text-sm text-gray-600">
                View your diagnosis history and monitor your plant health over time.
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={onNavigateHome}
          className="mt-8 bg-green-600 text-white px-8 py-3 rounded-lg font-medium hover:bg-green-700 transition-colors flex items-center space-x-2 mx-auto"
        >
          <span>Go to Dashboard</span>
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};