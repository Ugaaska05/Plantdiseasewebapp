import React from 'react';
import { Leaf, Users, Target, Award } from 'lucide-react';
import { useTranslation } from '../../hooks/useTranslation';

export const AboutPage: React.FC = () => {
  const { t } = useTranslation();

  return (
    <div className="max-w-6xl mx-auto px-4">
      {/* Hero Section */}
      <div className="text-center mb-16">
        <div className="bg-gradient-to-r from-green-600 to-green-700 text-white rounded-3xl p-12 mb-8">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">{t('aboutUs')}</h1>
          <p className="text-xl opacity-90 max-w-3xl mx-auto">
            {t('aboutDescription')}
          </p>
        </div>
      </div>

      {/* Mission Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
        <div className="bg-white rounded-2xl p-8 shadow-lg">
          <div className="flex items-center mb-6">
            <Target className="h-8 w-8 text-green-600 mr-3" />
            <h2 className="text-2xl font-bold text-gray-800">{t('ourMission')}</h2>
          </div>
          <p className="text-gray-600 leading-relaxed">
            {t('missionDescription')}
          </p>
        </div>

        <div className="bg-white rounded-2xl p-8 shadow-lg">
          <div className="flex items-center mb-6">
            <Award className="h-8 w-8 text-blue-600 mr-3" />
            <h2 className="text-2xl font-bold text-gray-800">{t('ourVision')}</h2>
          </div>
          <p className="text-gray-600 leading-relaxed">
            {t('visionDescription')}
          </p>
        </div>
      </div>

      {/* Technology Section */}
      <div className="bg-white rounded-3xl p-12 shadow-lg mb-16">
        <h2 className="text-3xl font-bold text-center text-gray-800 mb-8">{t('ourTechnology')}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-xl font-semibold text-gray-800 mb-4">{t('advancedML')}</h3>
            <p className="text-gray-600 mb-4">
              {t('mlDescription')}
            </p>
            <ul className="text-gray-600 space-y-2">
              <li>• Deep learning algorithms</li>
              <li>• High accuracy detection</li>
              <li>• Continuous model improvement</li>
              <li>• Real-time processing</li>
            </ul>
          </div>
          <div>
            <h3 className="text-xl font-semibold text-gray-800 mb-4">{t('supportedDiseases')}</h3>
            <p className="text-gray-600 mb-4">
              {t('diseasesDescription')}
            </p>
            <ul className="text-gray-600 space-y-2">
              <li>• Bacterial Spot</li>
              <li>• Early Blight</li>
              <li>• Late Blight</li>
              <li>• Leaf Mold</li>
              <li>• Septoria Leaf Spot</li>
              <li>• Spider Mites</li>
              <li>• Target Spot</li>
              <li>• Yellow Leaf Curl Virus</li>
              <li>• Mosaic Virus</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Team Section */}
      <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-3xl p-12">
        <div className="text-center">
          <Users className="h-12 w-12 text-green-600 mx-auto mb-6" />
          <h2 className="text-3xl font-bold text-gray-800 mb-6">{t('ourTeam')}</h2>
          <p className="text-gray-600 text-lg max-w-3xl mx-auto">
            {t('teamDescription')}
          </p>
        </div>
      </div>
    </div>
  );
};