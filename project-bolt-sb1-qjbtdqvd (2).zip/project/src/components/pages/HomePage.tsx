import React from 'react';
import { Leaf, Zap, Shield, Clock, ArrowRight, Users, TrendingUp, Award } from 'lucide-react';
import { useTranslation } from '../../hooks/useTranslation';

interface HomePageProps {
  onStartDiagnosis: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onStartDiagnosis }) => {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen">
      {/* Main Content */}
      <main className="relative">
        <div className="max-w-6xl mx-auto px-4 py-16">
          {/* Simple Welcome Section */}
          <div className="text-center mb-16">
            <div className="w-24 h-24 mx-auto mb-8 rounded-full overflow-hidden bg-white dark:bg-gray-800 p-2 shadow-lg">
              <img 
                src="/IMG_2600 copy.PNG" 
                alt="Hiigsigroup Logo" 
                className="w-full h-full object-cover rounded-full"
              />
            </div>
            
            <h1 className="text-5xl font-bold text-green-600 mb-6">
              {t('welcomeBack')}
            </h1>
            
            <div className="bg-white rounded-2xl p-8 shadow-lg mb-8 max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold text-gray-800 mb-4">
                {t('title')}
              </h2>
              <p className="text-lg text-gray-600 leading-relaxed">
                Welcome! You can now start diagnosing your plants. Upload a photo of your plant leaf to get instant disease detection and treatment recommendations.
              </p>
            </div>
          </div>

          {/* Simple Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <div className="bg-white rounded-2xl p-6 shadow-lg text-center">
              <div className="bg-green-500 p-3 rounded-lg w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Zap className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">{t('aiPowered')}</h3>
              <p className="text-gray-600">
                Advanced technology trained on plant images for accurate disease detection.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg text-center">
              <div className="bg-blue-500 p-3 rounded-lg w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Clock className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">{t('instantResults')}</h3>
              <p className="text-gray-600">
                Get immediate diagnosis and treatment recommendations within seconds.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg text-center">
              <div className="bg-purple-500 p-3 rounded-lg w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Shield className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">{t('expertRecommendations')}</h3>
              <p className="text-gray-600">
                Receive professional treatment suggestions based on the identified disease.
              </p>
            </div>
          </div>

          {/* How It Works */}
          <div className="bg-white rounded-2xl p-8 mb-16 shadow-lg">
            <h3 className="text-3xl font-bold text-center text-gray-800 mb-8">{t('howItWorks')}</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="bg-green-500 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                  1
                </div>
                <h4 className="text-xl font-bold text-gray-800 mb-3">{t('step1Title')}</h4>
                <p className="text-gray-600">{t('step1Description')}</p>
              </div>
              <div className="text-center">
                <div className="bg-blue-500 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                  2
                </div>
                <h4 className="text-xl font-bold text-gray-800 mb-3">{t('step2Title')}</h4>
                <p className="text-gray-600">Our system analyzes the image to identify diseases.</p>
              </div>
              <div className="text-center">
                <div className="bg-purple-500 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                  3
                </div>
                <h4 className="text-xl font-bold text-gray-800 mb-3">{t('step3Title')}</h4>
                <p className="text-gray-600">{t('step3Description')}</p>
              </div>
            </div>
          </div>

          {/* User Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <div className="bg-green-500 rounded-2xl p-6 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100 text-lg">{t('yourDiagnoses')}</p>
                  <p className="text-3xl font-bold">0</p>
                </div>
                <TrendingUp className="h-10 w-10 text-green-200" />
              </div>
            </div>

            <div className="bg-blue-500 rounded-2xl p-6 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-lg">{t('accuracyRate')}</p>
                  <p className="text-3xl font-bold">94%</p>
                </div>
                <Award className="h-10 w-10 text-blue-200" />
              </div>
            </div>

            <div className="bg-purple-500 rounded-2xl p-6 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-lg">{t('community')}</p>
                  <p className="text-3xl font-bold">10K+</p>
                </div>
                <Users className="h-10 w-10 text-purple-200" />
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="text-center">
            <div className="bg-green-600 rounded-2xl p-8">
              <h3 className="text-3xl font-bold text-white mb-4">{t('readyToAnalyze')}</h3>
              <p className="text-lg text-green-100 mb-6 max-w-2xl mx-auto">
                Start your first plant health diagnosis now
              </p>
              <button
                onClick={onStartDiagnosis}
                className="bg-white text-green-600 hover:bg-gray-50 px-8 py-3 rounded-lg font-bold text-lg transition-colors flex items-center space-x-2 mx-auto"
              >
                <span>{t('startDiagnosis')}</span>
                <ArrowRight className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};