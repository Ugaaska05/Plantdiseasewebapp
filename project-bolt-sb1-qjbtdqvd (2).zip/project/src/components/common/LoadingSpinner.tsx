import React from 'react';
import { Loader2 } from 'lucide-react';

export const LoadingSpinner: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center py-12">
      <div className="relative">
        <div className="w-16 h-16 border-4 border-green-200 dark:border-green-800 rounded-full animate-pulse"></div>
        <Loader2 className="w-8 h-8 text-green-600 dark:text-green-400 animate-spin absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
      </div>
      <p className="mt-4 text-lg font-medium text-gray-700 dark:text-gray-300">Analyzing...</p>
      <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Please wait while we analyze your plant...</p>
    </div>
  );
};