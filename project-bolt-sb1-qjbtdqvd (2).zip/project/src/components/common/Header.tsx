import React from 'react';
import { LogOut, User as UserIcon, Home, Stethoscope, Info, Globe, Sun, Moon, CreditCard } from 'lucide-react';
import { User } from '@supabase/supabase-js';
import { useTranslation } from '../../hooks/useTranslation';
import { useDarkMode } from '../../hooks/useDarkMode';

interface HeaderProps {
  currentPage: 'welcome' | 'home' | 'diagnostic' | 'about' | 'pricing' | 'success' | 'adminDashboard';
  onPageChange: (page: 'welcome' | 'home' | 'diagnostic' | 'about' | 'pricing' | 'success') => void;
  user: User | null;
  onLogout: () => void;
  userRole: 'admin' | 'user' | null;
  onAdminAccess: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentPage, onPageChange, user, onLogout, userRole, onAdminAccess }) => {
  const { t, language, toggleLanguage } = useTranslation();
  const { isDarkMode, toggleDarkMode } = useDarkMode();

  console.log('Header - user:', user?.email);
  console.log('Header - userRole:', userRole);
  console.log('Header - currentPage:', currentPage);

  const navItems = [
    { id: 'welcome', label: t('home'), icon: Home },
    { id: 'diagnostic', label: t('diagnostic'), icon: Stethoscope },
    { id: 'about', label: t('about'), icon: Info },
  ];

  return (
    <header className="relative">
      <div className="bg-white dark:bg-gray-900 shadow-lg border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img 
                src="/IMG_2600 copy.PNG" 
                alt="Hiigsigroup Logo" 
                className="h-10 w-10 rounded-xl object-cover"
              />
              <div>
                <h1 className="text-lg font-bold text-gray-800 dark:text-white">
                  Hiigsigroup Plant Disease Classifier
                </h1>
                <p className="text-xs text-gray-500 dark:text-gray-400">Group 162</p>
              </div>
            </div>

            <nav className="flex items-center space-x-2">
              {navItems.map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => onPageChange(id as any)}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    currentPage === id
                      ? 'bg-green-600 dark:bg-green-500 text-white'
                      : 'text-gray-600 dark:text-gray-300 hover:text-green-600 dark:hover:text-green-400 hover:bg-green-50 dark:hover:bg-gray-800'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <Icon className="h-4 w-4" />
                    <span>{label}</span>
                  </div>
                </button>
              ))}
              
              <div className="flex items-center space-x-2">
                <Globe className="h-4 w-4 text-gray-600 dark:text-gray-400" />
                <button 
                  onClick={toggleLanguage}
                  className="px-3 py-1 text-sm font-medium text-gray-600 dark:text-gray-300 hover:text-green-600 dark:hover:text-green-400 transition-colors"
                >
                  {t('language')}
                </button>
              </div>
              
              <button
                onClick={toggleDarkMode}
                className="p-2 rounded-lg text-gray-600 dark:text-gray-300 hover:text-green-600 dark:hover:text-green-400 hover:bg-green-50 dark:hover:bg-gray-800 transition-colors"
                title={isDarkMode ? 'Light Mode' : 'Dark Mode'}
              >
                {isDarkMode ? (
                  <Sun className="h-4 w-4" />
                ) : (
                  <Moon className="h-4 w-4" />
                )}
              </button>
            </nav>

            {user && (
              <div className="flex items-center space-x-4">
                <div className="bg-gray-50 dark:bg-gray-800 rounded-lg px-4 py-2">
                  <div className="flex items-center space-x-3">
                    <div className="bg-blue-500 dark:bg-blue-600 p-2 rounded-lg">
                      <UserIcon className="h-4 w-4 text-white" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-800 dark:text-white text-sm">
                        {user.user_metadata?.name || user.email}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Admin Access Button - Available for all users */}
                {user && (
                <button
                  onClick={onAdminAccess}
                  className="px-4 py-2 rounded-lg font-medium text-sm transition-colors bg-purple-600 hover:bg-purple-700 text-white shadow-lg"
                  title="Access Admin Dashboard"
                >
                  <div className="flex items-center space-x-1">
                    <UserIcon className="h-3 w-3" />
                    <span>Admin Dashboard</span>
                  </div>
                </button>
                )}

                <button
                  onClick={onLogout}
                  className="bg-red-500 hover:bg-red-600 dark:bg-red-600 dark:hover:bg-red-700 text-white p-2 rounded-lg transition-colors"
                  title={t('logout')}
                >
                  <LogOut className="h-4 w-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};