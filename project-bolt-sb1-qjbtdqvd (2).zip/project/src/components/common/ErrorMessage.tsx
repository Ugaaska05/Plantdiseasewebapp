import React from 'react';
import { AlertCircle, RefreshCw } from 'lucide-react';

interface ErrorMessageProps {
  message: string;
  onRetry: () => void;
}

export const ErrorMessage: React.FC<ErrorMessageProps> = ({ message, onRetry }) => {
  return (
    <div className="bg-red-50 border border-red-200 rounded-2xl p-6 text-center">
      <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
      <h3 className="text-lg font-semibold text-red-800 mb-2">Error</h3>
      <p className="text-red-600 mb-4">{message}</p>
      {message.includes('Network error') && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4">
          <p className="text-yellow-800 text-sm">
            <strong>Backend Connection Issue:</strong> Make sure Flask server is running on port 5000
          </p>
          <p className="text-yellow-700 text-xs mt-1">
            Run: <code className="bg-yellow-100 px-1 rounded">npm run backend</code> or <code className="bg-yellow-100 px-1 rounded">npm run start</code>
          </p>
        </div>
      )}
      <button
        onClick={onRetry}
        className="flex items-center space-x-2 bg-red-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-red-700 transition-colors mx-auto"
      >
        <RefreshCw className="h-4 w-4" />
        <span>Try Again</span>
      </button>
    </div>
  );
};