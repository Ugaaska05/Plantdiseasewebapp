import React from 'react';
import { Leaf, Mail, Phone, MapPin } from 'lucide-react';
import { useTranslation } from '../hooks/useTranslation';

export const Footer: React.FC = () => {
  const { t } = useTranslation();

  return (
    <footer className="bg-green-800 text-white mt-16">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <img 
                src="/IMG_2600 copy.PNG" 
                alt="Hiigsigroup Logo" 
                className="h-8 w-8 rounded-lg object-cover"
              />
              <h3 className="text-xl font-bold">{t('title')}</h3>
            </div>
            <p className="text-green-100 mb-4 max-w-md">
              {t('welcomeSubtitle')}
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-green-100">
              <li><a href="#" className="hover:text-white transition-colors">{t('home')}</a></li>
              <li><a href="#" className="hover:text-white transition-colors">{t('diagnostic')}</a></li>
              <li><a href="#" className="hover:text-white transition-colors">{t('about')}</a></li>
              <li><a href="#" className="hover:text-white transition-colors">{t('contact')}</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-semibold mb-4">{t('contact')}</h4>
            <div className="space-y-3 text-green-100">
              <div className="flex items-center space-x-2">
                <Mail className="h-4 w-4" />
                <span className="text-sm">{t('contactEmail')}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4" />
                <span className="text-sm">{t('contactPhone')}</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="h-4 w-4" />
                <span className="text-sm">{t('contactAddress')}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-green-700 mt-8 pt-8 text-center">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-green-100 text-sm">
              {t('copyright')}
            </p>
            <div className="flex space-x-6 text-sm text-green-100">
              <a href="#" className="hover:text-white transition-colors">{t('privacyPolicy')}</a>
              <a href="#" className="hover:text-white transition-colors">{t('termsOfService')}</a>
              <a href="#" className="hover:text-white transition-colors">{t('support')}</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};