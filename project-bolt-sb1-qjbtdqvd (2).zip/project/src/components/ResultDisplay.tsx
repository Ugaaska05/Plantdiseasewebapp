import React from 'react';
import { CheckCircle, AlertTriangle, RotateCcw, TrendingUp } from 'lucide-react';
import { PredictionResult } from '../types';
import { useTranslation } from '../hooks/useTranslation';

interface ResultDisplayProps {
  result: PredictionResult;
  onTryAnother: () => void;
}

export const ResultDisplay: React.FC<ResultDisplayProps> = ({ result, onTryAnother }) => {
  const { t } = useTranslation();
  const isHealthy = result.label.toLowerCase().includes('healthy');
  const isNonPlant = result.label.toLowerCase().includes('not a plant');
  const isNonTomato = result.label.toLowerCase().includes('not a tomato');

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className={`p-6 ${
          isHealthy ? 'bg-green-50' : 
          isNonPlant || isNonTomato ? 'bg-yellow-50' : 
          'bg-red-50'
        }`}>
          <div className="flex items-center space-x-3 mb-4">
            {isHealthy ? (
              <CheckCircle className="h-8 w-8 text-green-600" />
            ) : isNonPlant || isNonTomato ? (
              <AlertTriangle className="h-8 w-8 text-yellow-600" />
            ) : (
              <AlertTriangle className="h-8 w-8 text-red-600" />
            )}
            <h3 className="text-2xl font-bold text-gray-800">
              {result.friendly_text}
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <TrendingUp className="h-5 w-5 text-gray-600" />
                  <span className="font-medium text-gray-700">{t('confidence')}</span>
                </div>
                <div className="bg-white rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-600">Accuracy</span>
                    <span className="font-bold text-lg">{result.confidence}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div
                      className={`h-3 rounded-full transition-all duration-1000 ${
                        result.confidence >= 80
                          ? 'bg-green-500'
                          : result.confidence >= 60
                          ? 'bg-yellow-500'
                          : 'bg-red-500'
                      }`}
                      style={{ width: `${result.confidence}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-gray-700 mb-2">{t('recommendation')}</h4>
              <div className="bg-white rounded-lg p-4">
                <p className="text-gray-600 leading-relaxed">{result.suggestion}</p>
              </div>
            </div>
          </div>

          <div className="mt-6 flex justify-center">
            <button
              onClick={onTryAnother}
              className="flex items-center space-x-2 bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors"
            >
              <RotateCcw className="h-4 w-4" />
              <span>{t('tryAnother')}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};