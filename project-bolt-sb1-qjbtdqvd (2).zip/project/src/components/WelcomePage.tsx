import React from 'react';
import { Zap, Shield, Clock, ArrowRight, Globe, Mail, Phone, MapPin } from 'lucide-react';
import { useTranslation } from '../hooks/useTranslation';
import { useDarkMode } from '../hooks/useDarkMode';

interface WelcomePageProps {
  onGetStarted: () => void;
  onNavigate?: (page: 'home' | 'about' | 'pricing') => void;
}

export const WelcomePage: React.FC<WelcomePageProps> = ({ onGetStarted, onNavigate }) => {
  const { t, language, toggleLanguage } = useTranslation();
  const { isDarkMode, toggleDarkMode } = useDarkMode();

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-green-50 to-teal-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 flex flex-col">
      <header className="bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm shadow-lg border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img 
                src="/IMG_2600 copy.PNG" 
                alt="Hiigsigroup Logo" 
                className="h-10 w-10 rounded-xl object-cover"
              />
              <div>
                <h1 className="text-lg font-bold text-gray-800 dark:text-white">Hiigsigroup Plant Disease Classifier</h1>
                <p className="text-xs text-gray-600 dark:text-gray-400">Group 162</p>
              </div>
            </div>

            <nav className="hidden md:flex items-center space-x-8">
              <button 
                onClick={() => onNavigate?.('home')}
                className="text-gray-600 dark:text-gray-300 hover:text-green-600 dark:hover:text-green-400 font-medium transition-colors"
              >
                {t('home')}
              </button>
              <button 
                onClick={() => onNavigate?.('about')}
                className="text-gray-600 dark:text-gray-300 hover:text-green-600 dark:hover:text-green-400 font-medium transition-colors"
              >
                {t('about')}
              </button>
              
              <div className="flex items-center space-x-2">
                <Globe className="h-4 w-4 text-gray-600 dark:text-gray-400" />
                <button 
                  onClick={toggleLanguage}
                  className="bg-transparent border-none outline-none font-medium text-gray-600 dark:text-gray-300 hover:text-green-600 dark:hover:text-green-400 transition-colors"
                >
                  {t('language')}
                </button>
              </div>
              
              <button
                onClick={toggleDarkMode}
                className="p-2 rounded-lg text-gray-600 dark:text-gray-300 hover:text-green-600 dark:hover:text-green-400 hover:bg-green-50 dark:hover:bg-gray-800 transition-colors"
                title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              >
                {isDarkMode ? (
                  <span className="text-lg">☀️</span>
                ) : (
                  <span className="text-lg">🌙</span>
                )}
              </button>
              
              <button
                onClick={onGetStarted}
                className="bg-green-600 dark:bg-green-500 text-white px-6 py-2 rounded-lg font-medium hover:bg-green-700 dark:hover:bg-green-600 transition-colors"
              >
                {t('signIn')}
              </button>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-1 relative overflow-hidden">
        <div className="relative z-10 max-w-6xl mx-auto px-4 py-16">
          <div className="text-center mb-16">
            <div className="mb-8">
              <div className="w-32 h-32 mx-auto mb-8 rounded-full overflow-hidden shadow-lg bg-white dark:bg-gray-800 p-2">
                <img 
                  src="/IMG_2600 copy.PNG" 
                  alt="Hiigsigroup Logo" 
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
            </div>
            <h1 className="text-6xl md:text-8xl font-bold text-green-600 mb-6 leading-tight">
              {t('welcomeTitle')}
            </h1>
            <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 shadow-lg mb-8">
              <h2 className="text-4xl md:text-5xl font-bold text-gray-800 dark:text-white mb-4">
                Hiigsigroup Plant Disease Classifier
              </h2>
              <p className="text-lg text-green-600 dark:text-green-400 font-semibold mb-4">
                Developed by Group 162
              </p>
              <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 max-w-4xl mx-auto leading-relaxed">
                AI-powered system for diagnosing plant diseases — offering fast, reliable detection and helpful treatment advice for farmers and agricultural communities.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-shadow">
              <div className="bg-green-500 p-4 rounded-2xl w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                <Zap className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">{t('aiPowered')}</h3>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                {t('aiDescription')}
              </p>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-shadow">
              <div className="bg-blue-500 p-4 rounded-2xl w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                <Clock className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">{t('instantResults')}</h3>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                {t('instantDescription')}
              </p>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-shadow">
              <div className="bg-purple-500 p-4 rounded-2xl w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                <Shield className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">{t('expertRecommendations')}</h3>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                {t('expertDescription')}
              </p>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-3xl p-12 mb-16 shadow-lg">
            <h3 className="text-4xl font-bold text-center text-gray-800 dark:text-white mb-12">{t('howItWorks')}</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  step: '1',
                  title: t('step1Title'),
                  description: t('step1Description'),
                  color: 'from-green-500 to-emerald-500'
                },
                {
                  step: '2',
                  title: t('step2Title'),
                  description: t('step2Description'),
                  color: 'from-blue-500 to-cyan-500'
                },
                {
                  step: '3',
                  title: t('step3Title'),
                  description: t('step3Description'),
                  color: 'from-purple-500 to-pink-500'
                }
              ].map((item, index) => (
                <div key={index} className="text-center group">
                  <div className={`bg-gradient-to-r ${item.color} text-white rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg`}>
                    {item.step}
                  </div>
                  <h4 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">{item.title}</h4>
                  <p className="text-gray-600 dark:text-gray-300 leading-relaxed">{item.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="text-center">
            <div className="bg-green-600 dark:bg-green-700 rounded-3xl p-12 shadow-lg">
              <h3 className="text-4xl font-bold text-white mb-6">{t('readyToAnalyze')}</h3>
              <p className="text-xl text-green-100 dark:text-green-200 mb-8 max-w-2xl mx-auto">
                {t('readyDescription')}
              </p>
              <button
                onClick={onGetStarted}
                className="bg-white dark:bg-gray-100 text-green-600 dark:text-green-700 hover:bg-gray-50 dark:hover:bg-gray-200 px-12 py-4 rounded-2xl font-bold text-xl transition-colors shadow-lg flex items-center space-x-3 mx-auto"
              >
                <span>{t('startDiagnosis')}</span>
                <ArrowRight className="h-6 w-6" />
              </button>
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-green-800 dark:bg-gray-900 text-white mt-16">
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <img 
                  src="/IMG_2600 copy.PNG" 
                  alt="Hiigsigroup Logo" 
                  className="h-8 w-8 rounded-lg object-cover"
                />
                <h3 className="text-xl font-bold">Hiigsigroup Plant Disease Classifier</h3>
              </div>
              <p className="text-green-100 dark:text-gray-300 mb-4 max-w-md">
                AI-powered system for diagnosing plant diseases — developed by Group 162 — offering fast, reliable detection and helpful treatment advice for farmers and agricultural communities.
              </p>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">{t('quickLinks')}</h4>
              <ul className="space-y-2 text-green-100 dark:text-gray-300">
                <li><button onClick={() => onNavigate?.('home')} className="hover:text-white dark:hover:text-white transition-colors">{t('home')}</button></li>
                <li><button className="hover:text-white dark:hover:text-white transition-colors">{t('diagnostic')}</button></li>
                <li><button onClick={() => onNavigate?.('about')} className="hover:text-white dark:hover:text-white transition-colors">{t('about')}</button></li>
                <li><button className="hover:text-white dark:hover:text-white transition-colors">{t('contact')}</button></li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">{t('contact')}</h4>
              <div className="space-y-3 text-green-100 dark:text-gray-300">
                <div className="flex items-center space-x-2">
                  <Mail className="h-4 w-4" />
                  <span className="text-sm">hiigsi162@gmail.com</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4" />
                  <span className="text-sm">+252 615 479005</span>
                </div>
                <div className="flex items-center space-x-2">
                  <MapPin className="h-4 w-4" />
                  <span className="text-sm">Somali Agricultural Innovation Center, Mogadishu</span>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-green-700 dark:border-gray-700 mt-8 pt-8 text-center">
            <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
              <p className="text-green-100 dark:text-gray-300 text-sm">
                © 2025 Hiigsigroup – Group 162. All rights reserved.
              </p>
              <div className="flex space-x-6 text-sm text-green-100 dark:text-gray-300">
                <button className="hover:text-white dark:hover:text-white transition-colors">{t('privacyPolicy')}</button>
                <button className="hover:text-white dark:hover:text-white transition-colors">{t('termsOfService')}</button>
                <button className="hover:text-white dark:hover:text-white transition-colors">{t('support')}</button>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};