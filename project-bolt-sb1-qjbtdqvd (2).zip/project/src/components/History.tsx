import React from 'react';
import { Clock, Trash2, CheckCircle, AlertTriangle } from 'lucide-react';
import { HistoryItem } from '../types';
import { useTranslation } from '../hooks/useTranslation';
import { supabase } from '../config/supabase';

interface HistoryProps {
  history: HistoryItem[];
  onClearHistory: () => void;
  onRefreshHistory?: () => void;
}

export const History: React.FC<HistoryProps> = ({ history, onClearHistory, onRefreshHistory }) => {
  const { t } = useTranslation();

  if (history.length === 0) {
    return (
      <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
        <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-500 text-lg">No previous diagnoses</p>
        <p className="text-gray-400 text-sm mt-2">
          Sign in to save your diagnosis history
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-bold text-gray-800">{t('history')}</h3>
          <button
            onClick={onClearHistory}
            className="flex items-center space-x-2 text-red-600 hover:text-red-700 transition-colors"
          >
            <Trash2 className="h-4 w-4" />
            <span className="text-sm font-medium">{t('clearHistory')}</span>
          </button>
        </div>
      </div>

      <div className="max-h-96 overflow-y-auto">
        {history.map((item) => {
          const isHealthy = item.prediction.label.toLowerCase().includes('healthy');
          
          return (
            <div key={item.id} className="p-4 border-b border-gray-100 hover:bg-gray-50 transition-colors">
              <div className="flex items-start space-x-4">
                <div className={`p-2 rounded-lg ${isHealthy ? 'bg-green-100' : 'bg-red-100'}`}>
                  {isHealthy ? (
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  ) : (
                    <AlertTriangle className="h-5 w-5 text-red-600" />
                  )}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <p className="font-medium text-gray-800 truncate">
                      {item.prediction.friendly_text}
                    </p>
                    <span className="text-xs text-gray-500 ml-2">
                      {new Date(item.timestamp).toLocaleDateString()}
                    </span>
                  </div>
                  
                  <div className="flex items-center space-x-4 text-sm text-gray-600">
                    <span>Confidence: {item.prediction.confidence}%</span>
                    <span className="truncate">{item.imageName}</span>
                  </div>
                  
                  <p className="text-sm text-gray-500 mt-1 line-clamp-2">
                    {item.prediction.suggestion}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};