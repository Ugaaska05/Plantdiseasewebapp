import { createClient } from '@supabase/supabase-js'

const supabaseUrl = "https://pqeghyztlzfhphfkzekb.supabase.co"
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBxZWdoeXp0bHpmaHBoZmt6ZWtiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMzMTIwMzAsImV4cCI6MjA2ODg4ODAzMH0.CMSg--ps0qlDUC64vcw4ZbovXJCL2TqfsTHXGn7K-zU"

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables')
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type Database = {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          name: string | null
          email: string
          password_hash: string | null
          created_at: string
          role: string | null
          disabled: boolean | null
        }
        Insert: {
          id?: string
          name?: string | null
          email: string
          password_hash?: string | null
          created_at?: string
          role?: string | null
          disabled?: boolean | null
        }
        Update: {
          id?: string
          name?: string | null
          email?: string
          password_hash?: string | null
          created_at?: string
          role?: string | null
          disabled?: boolean | null
        }
      }
      predictions: {
        Row: {
          id: number
          created_at: string
          user_id: number | null
          friendly_text: string | null
          suggestion: string | null
          confidence: number | null
          language: string | null
          label: string | null
        }
        Insert: {
          id?: number
          created_at?: string
          user_id?: number | null
          friendly_text?: string | null
          suggestion?: string | null
          confidence?: number | null
          language?: string | null
          label?: string | null
        }
        Update: {
          id?: number
          created_at?: string
          user_id?: number | null
          friendly_text?: string | null
          suggestion?: string | null
          confidence?: number | null
          language?: string | null
          label?: string | null
        }
      }
      user_sessions: {
        Row: {
          id: number
          user_id: number
          token: string
          expires_at: string
          created_at: string
        }
        Insert: {
          id?: number
          user_id: number
          token: string
          expires_at: string
          created_at?: string
        }
        Update: {
          id?: number
          user_id?: number
          token?: string
          expires_at?: string
          created_at?: string
        }
      }
      system_settings: {
        Row: {
          id: number
          setting_key: string
          setting_value: string | null
          description: string | null
          updated_at: string
        }
        Insert: {
          id?: number
          setting_key: string
          setting_value?: string | null
          description?: string | null
          updated_at?: string
        }
        Update: {
          id?: number
          setting_key?: string
          setting_value?: string | null
          description?: string | null
          updated_at?: string
        }
      }
    }
  }
}