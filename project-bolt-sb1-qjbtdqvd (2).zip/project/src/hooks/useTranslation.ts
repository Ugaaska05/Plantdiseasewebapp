import { useState } from 'react';
import { translations, TranslationKey, Language } from '../utils/translations';

export const useTranslation = () => {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: TranslationKey): string => {
    return translations[language][key] || key;
  };

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'so' : 'en');
  };

  return { t, language, setLanguage, toggleLanguage };
};