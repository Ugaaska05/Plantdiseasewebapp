import { useState, useEffect } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '../config/supabase';

export interface AuthState {
  user: User | null;
  session: Session | null;
  loading: boolean;
}

export const useSupabaseAuth = () => {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    session: null,
    loading: true,
  });
  const [error, setError] = useState<string>('');

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setAuthState({
        user: session?.user ?? null,
        session,
        loading: false,
      });
    });

    // Listen for auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setAuthState({
        user: session?.user ?? null,
        session,
        loading: false,
      });
    });

    return () => subscription.unsubscribe();
  }, []);

  const signUp = async (email: string, password: string, name: string) => {
    setError('');
    
    try {
      // Sign up with Supabase Auth
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/`,
          data: {
            name,
          },
        },
      });

      if (error) throw error;
      
      // User record will be created after email confirmation
      // via database trigger or in signIn function
      
      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  };

  const signIn = async (email: string, password: string) => {
    setError('');
    
    try {
      // Authenticate with Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (authError) {
        throw authError;
      }
      
      if (!authData.user) throw new Error('Authentication failed');

      // Check if email is confirmed
      if (!authData.user.email_confirmed_at) {
        throw new Error('Please check your email and click the confirmation link before signing in.');
      }

      // First check if user is disabled in our custom users table
      const { data: userData, error: userCheckError } = await supabase
        .from('users')
        .select('disabled')
        .eq('email', authData.user.email)
        .single();

      // If user exists and is disabled, show disabled message immediately
      if (!userCheckError && userData && userData.disabled === true) {
        throw new Error('Your account has been disabled. Please contact admin for assistance.');
      }

      // Sync user data with our users table using upsert
      // Get existing role from database or default to 'user'
      const { data: existingUser } = await supabase
        .from('users')
        .select('role, disabled')
        .eq('email', authData.user.email)
        .single();
      
      // Validate role is either 'user' or 'admin'
      const role = (existingUser?.role === 'admin' || existingUser?.role === 'user') 
        ? existingUser.role 
        : 'user';
      
      // Check if user is disabled after authentication
      if (existingUser?.disabled === true) {
        throw new Error('Your account has been disabled. Please contact admin for assistance.');
      }
      
      const { error: upsertError } = await supabase
        .from('users')
        .upsert({
          id: authData.user.id,
          email: authData.user.email!,
          name: authData.user.user_metadata?.name || 'User',
          role: role,
          disabled: false,
          password_hash: 'supabase_auth_managed'
        }, { onConflict: 'id' });

      if (upsertError) {
        console.warn('Failed to sync user data:', upsertError);
      }

      return { data: authData, error: null };
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  };

  const signOut = async () => {
    setError('');
    
    try {
      await supabase.auth.signOut();
    } catch (err: any) {
      setError(err.message);
      throw err;
    }
  };

  // Add setAuthState to the hook's return

  return {
    ...authState,
    signUp,
    signIn,
    signOut,
    error,
    setError
  };
};