const API_BASE_URL = 'http://localhost:5000';
import { supabase } from '../config/supabase';

// Test backend connection
export const testBackendConnection = async (): Promise<boolean> => {
  try {
    const response = await fetch(`${API_BASE_URL}/`, {
      method: 'GET',
    });
    
    if (!response.ok) {
      console.error('Backend connection failed:', response.status);
      return false;
    }
    
    const data = await response.json();
    console.log('Backend connection successful:', data);
    return true;
  } catch (error) {
    console.error('Backend connection error:', error);
    return false;
  }
};

export const predictDisease = async (file: File): Promise<any> => {
  const formData = new FormData();
  formData.append('file', file);

  const response = await fetch(`${API_BASE_URL}/predict`, {
    method: 'POST',
    body: formData,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Network error' }));
    throw new Error(errorData.error || 'Prediction failed');
  }

  const result = await response.json();
  return {
    label: result.prediction || 'Unknown',
    friendly_text: result.prediction || 'Analysis Complete',
    suggestion: getSuggestionFromPrediction(result),
    confidence: parseFloat(result.confidence?.replace('%', '') || '0'),
    language: 'en',
    stage: result.stage,
    type: result.type
  };
};

const getSuggestionFromPrediction = (result: any): string => {
  const prediction = result.prediction?.toLowerCase() || '';
  if (prediction.includes('not a plant')) {
    return 'Please upload a clear image of a plant leaf for accurate analysis.';
  }
  if (prediction.includes('not a tomato')) {
    return 'This system is specialized for tomato plant disease detection. Please upload a tomato plant leaf image.';
  }
  if (prediction.includes('healthy')) {
    return 'Great! Your tomato plant appears healthy. Continue with your current care routine and monitor regularly.';
  }
  if (prediction.includes('bacterial_spot')) {
    return 'Apply copper-based bactericide. Improve air circulation and avoid overhead watering.';
  }
  if (prediction.includes('early_blight')) {
    return 'Remove affected leaves, apply fungicide, and ensure proper plant spacing for air circulation.';
  }
  if (prediction.includes('late_blight')) {
    return 'Remove infected plants immediately. Apply preventive fungicide to healthy plants.';
  }
  if (prediction.includes('leaf_mold')) {
    return 'Improve ventilation, reduce humidity, and apply appropriate fungicide treatment.';
  }
  if (prediction.includes('septoria')) {
    return 'Remove lower leaves, apply fungicide, and avoid watering leaves directly.';
  }
  if (prediction.includes('spider_mites')) {
    return 'Increase humidity, use insecticidal soap, or introduce beneficial predatory mites.';
  }
  if (prediction.includes('target_spot')) {
    return 'Apply fungicide, improve air circulation, and remove affected plant debris.';
  }
  if (prediction.includes('yellow_leaf_curl')) {
    return 'Control whitefly vectors, remove infected plants, and use virus-resistant varieties.';
  }
  if (prediction.includes('mosaic_virus')) {
    return 'Remove infected plants, control aphid vectors, and sanitize tools between plants.';
  }
  if (prediction.includes('disease')) {
    return 'Disease detected. Consult with a local agricultural extension office for specific treatment recommendations.';
  }
  return 'Analysis complete. Monitor your plant closely and consult agricultural experts if needed.';
};

export const saveToUserHistory = async (prediction: any, imageName: string) => {
  try {
    // Get current user session
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session?.user) {
      throw new Error('User not authenticated');
    }

    // Get user from users table to get the UUID
    const { data: userData, error: userError } = await supabase
      .from('users')
      .select('id')
      .eq('email', session.user.email)
      .single();

    if (userError || !userData) {
      throw new Error('User not found in database');
    }

    // Save to Supabase predictions table with proper user_id
    const { data, error } = await supabase
      .from('predictions')
      .insert({
        user_id: userData.id,
        friendly_text: prediction.friendly_text,
        suggestion: prediction.suggestion,
        confidence: prediction.confidence,
        language: prediction.language || 'en',
        label: prediction.label
      })
      .select()
      .single();

    if (error) {
      throw new Error('Failed to save prediction to database');
    }

    return data;
  } catch (error) {
    console.error('Error saving prediction:', error);
    throw error;
  }
};