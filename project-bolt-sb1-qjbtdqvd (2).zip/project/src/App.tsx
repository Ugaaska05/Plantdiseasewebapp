import React, { useState, useCallback } from 'react';
import { Header } from './components/common/Header';
import { HomePage } from './components/pages/HomePage';
import { AboutPage } from './components/pages/AboutPage';
import { SuccessPage } from './components/pages/SuccessPage';
import { WelcomePage } from './components/WelcomePage';
import { ImageUpload } from './components/ImageUpload';
import { LoadingSpinner } from './components/common/LoadingSpinner';
import { ResultDisplay } from './components/ResultDisplay';
import { History } from './components/History';
import { ErrorMessage } from './components/common/ErrorMessage';
import { SupabaseLoginForm } from './components/auth/SupabaseLoginForm';
import { SupabaseSignupForm } from './components/auth/SupabaseSignupForm';
import { AdminDashboard } from './components/dashboard/AdminDashboard';
import { predictDisease } from './services/api';
import { useSupabaseAuth } from './hooks/useSupabaseAuth';
import { useTranslation } from './hooks/useTranslation';
import { saveToUserHistory, testBackendConnection } from './services/api';
import { supabase } from './config/supabase';
import {
  PredictionResult,
  HistoryItem,
} from './types';

type AppState = 'idle' | 'loading' | 'result' | 'error';
type Page = 'welcome' | 'home' | 'diagnostic' | 'about' | 'success' | 'adminDashboard';

function App() {
  const { t } = useTranslation();
  const {
    user,
    session,
    loading: authLoading,
    signIn,
    signUp,
    signOut,
    error: authError,
    setError,
  } = useSupabaseAuth();

  const isAuthenticated = !!user;
  const [currentPage, setCurrentPage] = useState<Page>('welcome');
  const [state, setState] = useState<AppState>('idle');
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [result, setResult] = useState<PredictionResult | null>(null);
  const [error, setAppError] = useState<string>('');
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showLoginForm, setShowLoginForm] = useState(false);
  const [showSignupForm, setShowSignupForm] = useState(false);
  const [userRole, setUserRole] = useState<'admin' | 'user' | null>(null);

  // Test backend connection on app start
  React.useEffect(() => {
    const checkBackendConnection = async () => {
      const isConnected = await testBackendConnection();
      if (!isConnected) {
        console.warn('Backend connection failed. Make sure Flask server is running on port 5000');
      }
    };
    
    checkBackendConnection();
  }, []);

  // Load user-specific history only when authenticated
  React.useEffect(() => {
    if (isAuthenticated && user) {
      loadUserHistory();
    } else {
      setHistory([]); // Clear history for non-authenticated users
    }
  }, [isAuthenticated, user]);

  // Check user role from database when user changes
  React.useEffect(() => {
    console.log('App useEffect - user changed:', user?.email);
    if (user?.email) {
      checkUserRole(user.email);
    } else {
      setUserRole(null);
    }
  }, [user]);

  const checkUserRole = async (email: string) => {
    console.log('App checkUserRole - starting for email:', email);
    try {
      // Get user role from database
      const { data, error } = await supabase
        .from('users')
        .select('role')
        .eq('email', email)
        .single();

      if (error) {
        console.log('App checkUserRole - user not found in database, defaulting to user role');
        setUserRole('user');
      } else {
        const role = data.role || 'user';
        console.log('App checkUserRole - database returned role:', role);
        setUserRole(role);
      }
    } catch (error) {
      console.error('Error checking user role:', error);
      // Fallback to user role on error
      setUserRole('user');
    }
  };

  const loadUserHistory = async () => {
    try {
      // Get user from users table
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('id')
        .eq('email', user?.email)
        .single();

      if (userError || !userData) {
        console.error('User not found in database');
        return;
      }

      // Load user's predictions from database
      const { data: predictions, error } = await supabase
        .from('predictions')
        .select('*')
        .eq('user_id', userData.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) {
        console.error('Error loading user history:', error);
        return;
      }

      // Convert to HistoryItem format
      const historyItems: HistoryItem[] = predictions.map((p: any) => ({
        id: p.id.toString(),
        imageName: 'Plant Image',
        prediction: {
          label: p.label || 'Disease Analysis',
          friendly_text: p.friendly_text || 'Analysis Complete',
          suggestion: p.suggestion || 'No suggestion available',
          confidence: p.confidence || 0,
          language: p.language || 'en'
        },
        timestamp: p.created_at
      }));

      setHistory(historyItems);
    } catch (error) {
      console.error('Failed to load user history:', error);
    }
  };

  const handleGetStarted = () => setShowLoginForm(true);

  const handleImageSelect = useCallback((file: File) => {
    setSelectedImage(file);
    setAppError('');
  }, []);

  const handleClearImage = useCallback(() => {
    setSelectedImage(null);
    setState('idle');
    setResult(null);
    setAppError('');
  }, []);

  const handlePredict = useCallback(async () => {
    if (!selectedImage) return;

    setState('loading');
    setAppError('');

    try {
      const prediction = await predictDisease(selectedImage);
      setResult(prediction);
      setState('result');

      const historyItem: HistoryItem = {
        id: Date.now().toString(),
        imageName: selectedImage.name,
        prediction,
        timestamp: new Date().toISOString(),
      };

      // Save to database only if user is logged in
      if (isAuthenticated && user) {
        try {
          await saveToUserHistory(prediction, selectedImage.name);
          // Reload history from database after saving
          await loadUserHistory();
        } catch (error) {
          console.error('Failed to save to database:', error);
        }
      } else {
        // For non-authenticated users, just add to current session
        setHistory(prev => [historyItem, ...prev.slice(0, 49)]);
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unexpected error occurred';
      setAppError(errorMessage);
      setState('error');
    }
  }, [selectedImage, isAuthenticated, user]);

  const handleTryAnother = useCallback(() => {
    handleClearImage();
  }, [handleClearImage]);

  const handleRetry = useCallback(() => {
    setState('idle');
    setAppError('');
  }, []);

  const handleClearHistory = useCallback(() => {
    if (isAuthenticated && user) {
      // Clear database history for authenticated users
      clearUserDatabaseHistory();
    } else {
      // Clear session history for non-authenticated users
      setHistory([]);
    }
  }, [isAuthenticated, user]);

  const clearUserDatabaseHistory = async () => {
    try {
      // Get user from users table
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('id')
        .eq('email', user?.email)
        .single();

      if (userError || !userData) {
        console.error('User not found in database');
        return;
      }

      // Delete user's predictions
      const { error } = await supabase
        .from('predictions')
        .delete()
        .eq('user_id', userData.id);

      if (error) {
        console.error('Error clearing user history:', error);
        return;
      }

      setHistory([]);
    } catch (error) {
      console.error('Failed to clear user history:', error);
    }
  };

  const handleStartDiagnosis = useCallback(() => {
    setCurrentPage('diagnostic');
  }, []);

  const handleSwitchToPrediction = useCallback(() => {
    setCurrentPage('diagnostic');
  }, []);

  const handleAdminAccess = useCallback(() => {
    console.log('handleAdminAccess - clicked, userRole:', userRole);
    console.log('handleAdminAccess - user email:', user?.email);
    
    if (userRole === 'admin') {
      console.log('handleAdminAccess - user is admin, navigating to admin dashboard');
      setCurrentPage('adminDashboard');
    } else if (userRole === 'user') {
      console.log('handleAdminAccess - user is not admin, showing alert');
      alert('You are not admin - Access denied');
    } else {
      console.log('handleAdminAccess - userRole is null, still loading');
      alert('Loading user permissions...');
    }
  }, [userRole, user]);

  const handleLogin = useCallback(
    async (email: string, password: string) => {
      console.log('handleLogin - attempting login for:', email);
      try {
        await signIn(email, password);
        console.log('handleLogin - signIn successful');
        setShowLoginForm(false);
        // Don't set page here - let checkUserRole handle navigation
      } catch (err) {
        console.log('handleLogin - signIn failed:', err);
        setError(err instanceof Error ? err.message : 'User login failed');
      }
    },
    [signIn, setError]
  );

  const handleSignup = useCallback(
    async (email: string, password: string, name: string) => {
      try {
        await signUp(email, password, name);

        setShowSignupForm(false);
        setCurrentPage('welcome');
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Registration failed');
      }
    },
    [signUp, setError]
  );

  const handleLogout = useCallback(() => {
    signOut();
    setCurrentPage('welcome');
    setShowLoginForm(false);
    setShowSignupForm(false);
    handleClearImage();
  }, [signOut, handleClearImage]);

  // Show Signup
  if (!isAuthenticated && showSignupForm) {
    return (
      <SupabaseSignupForm
        onSignup={handleSignup}
        onBackToLogin={() => {
          setShowSignupForm(false);
          setShowLoginForm(true);
        }}
        isLoading={authLoading}
        error={authError}
      />
    );
  }

  // Show Login
  if (!isAuthenticated && showLoginForm) {
    return (
      <SupabaseLoginForm
        onLogin={handleLogin}
        isLoading={authLoading}
        error={authError}
        onSwitchToRegister={() => {
          setShowLoginForm(false);
          setShowSignupForm(true);
        }}
      />
    );
  }

  // Show Public
  if (!isAuthenticated && !showLoginForm && !showSignupForm) {
    return (
      <WelcomePage
        onGetStarted={handleGetStarted}
        onNavigate={(page) => setCurrentPage(page)}
      />
    );
  }

  const renderDiagnosticContent = () => {
    switch (state) {
      case 'loading':
        return <LoadingSpinner />;
      case 'result':
        return result ? <ResultDisplay result={result} onTryAnother={handleTryAnother} /> : null;
      case 'error':
        return <ErrorMessage message={error} onRetry={handleRetry} />;
      default:
        return (
          <div className="space-y-8">
            <ImageUpload
              onImageSelect={handleImageSelect}
              selectedImage={selectedImage}
              onClearImage={handleClearImage}
              disabled={state === 'loading'}
            />
            {selectedImage && state === 'idle' && (
              <div className="text-center">
                <button
                  onClick={handlePredict}
                  className="bg-green-600 text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-green-700 transition-colors shadow-lg"
                >
                  Analyze Plant
                </button>
              </div>
            )}
          </div>
        );
    }
  };

  const isAdmin = userRole === 'admin';

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      {currentPage !== 'adminDashboard' && (
        <Header
          currentPage={currentPage}
          onPageChange={setCurrentPage}
          user={user}
          onLogout={handleLogout}
          userRole={userRole}
          onAdminAccess={handleAdminAccess}
        />
      )}
      
      <main className="pb-16">
        {currentPage === 'success' ? (
          <SuccessPage onNavigateHome={() => setCurrentPage('home')} />
        ) : currentPage === 'adminDashboard' && isAuthenticated && isAdmin ? (
          <AdminDashboard
            currentUser={{
              id: user!.id,
              name: user!.user_metadata?.name || user!.email || 'Admin',
              email: user!.email || '',
              role: 'admin',
              createdAt: user!.created_at || new Date().toISOString()
            }}
            onLogout={handleLogout}
            onSwitchToPrediction={handleSwitchToPrediction}
          />
        ) : currentPage === 'about' ? (
          <AboutPage />
        ) : currentPage === 'diagnostic' ? (
          <div className="max-w-6xl mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">{renderDiagnosticContent()}</div>
              <div className="lg:col-span-1">
                <History 
                  history={history} 
                  onClearHistory={handleClearHistory}
                />
              </div>
            </div>
          </div>
        ) : (
          <HomePage onStartDiagnosis={handleStartDiagnosis} />
        )}
      </main>
    </div>
  );
}

export default App;