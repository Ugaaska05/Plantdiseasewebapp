export interface PredictionResult {
  label: string;
  friendly_text: string;
  suggestion: string;
  confidence: number;
  language: string;
}

export interface HistoryItem {
  id: string;
  imageName: string;
  prediction: PredictionResult;
  timestamp: string;
  imageUrl?: string;
}

export interface Language {
  code: string;
  name: string;
  flag: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'user';
  createdAt: string;
  email_verified?: boolean;
  disabled?: boolean;
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  token: string | null;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterCredentials {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
}