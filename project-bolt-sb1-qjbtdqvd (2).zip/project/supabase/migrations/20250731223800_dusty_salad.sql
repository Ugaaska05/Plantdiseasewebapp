/*
  # Create Default Admin User

  1. New Admin User
    - Creates a default admin account for system management
    - Email: admin@hiigsigroup.com
    - Role: admin
    - Status: active (not disabled)

  2. Security
    - Admin user has full system access
    - Can manage all users and view all predictions
*/

-- Insert default admin user (only if doesn't exist)
INSERT INTO users (name, email, password_hash, role, disabled) 
VALUES (
  'Admin User', 
  'admin@hiigsigroup.com', 
  '$2b$12$LQv3c1yqBwlVHpw1tsJ/Oe7DJtqqbpXSMmHfrHsuXOHiQxOUjm1G2', -- password: admin123
  'admin', 
  false
)
ON CONFLICT (email) DO NOTHING;