/*
  # Disable Email Confirmation

  This migration disables email confirmation for the authentication system
  to allow immediate user access without email verification.

  1. Configuration Changes
    - Disable email confirmation requirement
    - Allow immediate user access after signup
  
  2. Security Notes
    - Email confirmation is disabled for development/testing
    - In production, consider enabling email confirmation for security
*/

-- Update auth configuration to disable email confirmation
-- Note: This needs to be done in Supabase Dashboard under Authentication > Settings
-- Set "Enable email confirmations" to OFF

-- For now, we'll ensure users can be created without email confirmation
-- by handling it in the application code