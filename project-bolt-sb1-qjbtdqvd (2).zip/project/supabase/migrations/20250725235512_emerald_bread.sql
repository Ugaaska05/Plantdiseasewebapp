/*
  # Disable RLS on Users Table

  1. Security Changes
    - Disable Row Level Security on `users` table
    - Remove all RLS policies
    - Allow direct access to users table

  2. Notes
    - This removes all security restrictions
    - Direct database access now allowed
    - Use with caution in production
*/

-- Disable Row Level Security on users table
ALTER TABLE users DISABLE ROW LEVEL SECURITY;

-- Drop all existing policies on users table
DROP POLICY IF EXISTS "Users can read own data" ON users;
DROP POLICY IF EXISTS "Admins can read all users" ON users;
DROP POLICY IF EXISTS "Admins can update users" ON users;
DROP POLICY IF EXISTS "Admins can delete users" ON users;

-- Ensure table is accessible
GRANT ALL ON users TO anon;
GRANT ALL ON users TO authenticated;