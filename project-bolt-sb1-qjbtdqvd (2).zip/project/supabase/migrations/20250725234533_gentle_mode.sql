/*
  # Create Default Admin and User Accounts

  1. New Users
    - Creates default admin account
    - Creates default user account
    - Both accounts are enabled by default

  2. Security
    - Passwords are properly hashed using bcrypt
    - Admin has full access
    - User has standard access
*/

-- Insert default admin user
INSERT INTO users (name, email, password_hash, role, disabled) 
VALUES (
  'Admin User',
  'admin@example.com',
  '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXzgVjHUxrLW', -- admin123
  'admin',
  false
) ON CONFLICT (email) DO NOTHING;

-- Insert default regular user
INSERT INTO users (name, email, password_hash, role, disabled) 
VALUES (
  'Regular User',
  'user@example.com',
  '$2b$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- user123
  'user',
  false
) ON CONFLICT (email) DO NOTHING;

-- Create predictions table if it doesn't exist
CREATE TABLE IF NOT EXISTS predictions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  friendly_text text,
  suggestion text,
  confidence decimal(5,2),
  language varchar(10) DEFAULT 'en',
  label text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on predictions table
ALTER TABLE predictions ENABLE ROW LEVEL SECURITY;

-- Create policy for predictions
CREATE POLICY "Users can read own predictions"
  ON predictions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own predictions"
  ON predictions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Admins can read all predictions
CREATE POLICY "Admins can read all predictions"
  ON predictions
  FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM users 
    WHERE id::text = auth.uid()::text 
    AND role = 'admin'
  ));