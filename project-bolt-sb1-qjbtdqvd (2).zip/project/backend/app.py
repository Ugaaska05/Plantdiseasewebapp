from flask import Flask, request, jsonify
from flask_cors import CORS
from supabase import create_client, Client
import numpy as np
import os
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image

# Initialize Flask
app = Flask(__name__)

# Configure CORS properly
CORS(app, 
     origins=["http://localhost:5173"],
     methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
     allow_headers=["Content-Type", "Authorization", "Accept"],
     supports_credentials=True)

# Supabase Configuration
# Get Supabase credentials from environment or use defaults
SUPABASE_URL = os.getenv("SUPABASE_URL", "https://pqeghyztlzfhphfkzekb.supabase.co")
SUPABASE_SERVICE_ROLE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBxZWdoeXp0bHpmaHBoZmt6ZWtiIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1MzMxMjAzMCwiZXhwIjoyMDY4ODg4MDMwfQ.kOQRqrU5xWNJJkFSGGD_gxV6VC6-xHGA3zmykx8v_0s")

# Initialize Supabase client
supabase: Client = create_client(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)

# Handle preflight requests
@app.before_request
def handle_preflight():
    if request.method == "OPTIONS":
        response = jsonify({'status': 'ok'})
        response.headers["Access-Control-Allow-Origin"] = "http://localhost:5173"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization, Accept"
        response.headers["Access-Control-Allow-Credentials"] = "true"
        return response, 200

# Add CORS headers to all responses
@app.after_request
def after_request(response):
    response.headers["Access-Control-Allow-Origin"] = "http://localhost:5173"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization, Accept"
    response.headers["Access-Control-Allow-Credentials"] = "true"
    return response

# Load models
try:
    gatekeeper_model = load_model("models/gatekeeper_model.keras")
    planttype_model = load_model("models/plant_type_model.keras")
    tomato_model = load_model("models/tomato_disease_densenet_model.keras")
    print("✅ All models loaded successfully.")
except Exception as e:
    print(f"❌ Error loading models: {e}")
    print("Make sure your models are in the models/ folder.")

# Class labels
planttype_classes = ['OtherPlant', 'Tomato']
tomato_classes = [
    'Tomato_Bacterial_spot', 'Tomato_Early_blight', 'Tomato_Late_blight',
    'Tomato_Leaf_Mold', 'Tomato_Septoria_leaf_spot', 'Tomato_Spider_mites_Two_spotted_spider_mite',
    'Tomato__Target_Spot', 'Tomato_Tomato_YellowLeaf_Curl_Virus',
    'Tomato__Tomato_mosaic_virus', 'Tomato_healthy'
]

@app.route('/', methods=['GET'])
def health_check():
    return jsonify({
        'status': 'healthy',
        'message': 'Plant Disease Classifier API is running.',
        'endpoints': ['/predict'],
        'frontend_url': 'http://localhost:5173',
        'supabase_connected': True
    })

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400

    file = request.files['file']
    os.makedirs('uploads', exist_ok=True)
    img_path = "uploads/temp.jpg"
    file.save(img_path)

    try:
        img = image.load_img(img_path, target_size=(224, 224))
        img_array = image.img_to_array(img) / 255.0
        img_array = np.expand_dims(img_array, axis=0)

        gate_pred = gatekeeper_model.predict(img_array)[0][0]
        if gate_pred < 0.5:
            os.remove(img_path)
            return jsonify({
                'stage': 'Gatekeeper',
                'prediction': 'This is NOT a plant 🌵',
                'confidence': f"{(1 - gate_pred) * 100:.2f}%"
            })

        plant_pred = planttype_model.predict(img_array)[0]
        plant_index = np.argmax(plant_pred)
        plant_label = planttype_classes[plant_index]

        if plant_label != 'Tomato':
            os.remove(img_path)
            return jsonify({
                'stage': 'Plant Type',
                'prediction': 'This is a plant, but NOT a tomato 🪴',
                'type': plant_label,
                'confidence': f"{np.max(plant_pred) * 100:.2f}%"
            })

        tomato_pred = tomato_model.predict(img_array)[0]
        tomato_index = np.argmax(tomato_pred)
        tomato_label = tomato_classes[tomato_index]
        confidence = float(np.max(tomato_pred)) * 100

        os.remove(img_path)

        if 'healthy' in tomato_label.lower():
            prediction_text = f"This tomato plant is healthy 🌿: {tomato_label}"
        else:
            prediction_text = f"This tomato plant has a disease 🦠: {tomato_label}"

        return jsonify({
            'stage': 'Tomato Disease',
            'prediction': prediction_text,
            'confidence': f"{confidence:.2f}%"
        })

    except Exception as e:
        if os.path.exists(img_path):
            os.remove(img_path)
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    print("\n🌿 Starting Plant Disease Classifier API...")
    print("API will be available at: http://localhost:5000")
    print("Frontend: http://localhost:5173")
    print("Database: Supabase PostgreSQL")
    print("Register new users via frontend\n")
    app.run(debug=True, host='0.0.0.0', port=5000)